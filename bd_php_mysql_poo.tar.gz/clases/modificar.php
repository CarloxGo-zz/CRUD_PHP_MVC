<?php 
	include_once('Conexion.php');
	include_once('../modulos/Controlador.php');

?>